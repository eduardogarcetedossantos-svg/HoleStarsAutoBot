# Hole Stars Auto Bot — protótipo Android

Este repositório contém somente a estrutura inicial de um aplicativo Android.

## Estado atual
- Projeto Android/Kotlin inicial.
- Tela simples de apresentação.
- Declaração de um serviço de acessibilidade.
- **Ainda não** captura a tela, reconhece os objetos, move o buraco ou joga sozinho.

## Próximas etapas
1. Compilar e instalar o APK de teste.
2. Implementar captura de tela com consentimento explícito do Android.
3. Validar reconhecimento dos objetivos variáveis no canto superior esquerdo.
4. Implementar e testar planejamento de rota.
5. Só então adicionar comandos de movimento, com ativação e interrupção controladas pelo usuário.

O serviço de acessibilidade exige ativação manual nas configurações do Android. Não habilite serviços que você não reconheça.
