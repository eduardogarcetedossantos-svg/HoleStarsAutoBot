package com.holestars.autobot

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.util.Log

/**
 * Estrutura inicial do serviço. Por segurança, ainda não executa toques
 * nem controla o Hole Stars. O reconhecimento e a lógica de movimento
 * serão implementados depois de validar a captura e a interface do jogo.
 */
class GameAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Etapa inicial: nenhum comando é enviado ao jogo.
        Log.d("HoleStarsAutoBot", "Evento de acessibilidade recebido")
    }

    override fun onInterrupt() {
        Log.d("HoleStarsAutoBot", "Serviço interrompido")
    }
}
