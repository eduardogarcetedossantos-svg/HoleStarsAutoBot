package com.holestars.autobot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Hole Stars Auto Bot — protótipo"
            textSize = 22f
            setPadding(24, 32, 24, 12)
        }
        val info = TextView(this).apply {
            text = "Esta é apenas a estrutura inicial. Ainda não reconhece objetos nem movimenta o jogo. A automação será adicionada e testada em etapas."
            textSize = 16f
            setPadding(24, 12, 24, 24)
        }
        val accessibility = Button(this).apply {
            text = "Abrir configurações de acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            addView(title)
            addView(info)
            addView(accessibility)
        }
        setContentView(layout)
    }
}
